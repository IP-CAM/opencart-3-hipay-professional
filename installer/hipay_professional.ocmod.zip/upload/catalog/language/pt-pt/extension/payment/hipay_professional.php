<?php

// Text
$_['text_title'] = 'HiPay - Pague com cartões de crédito ou métodos de pagamento locais';
$_['hipay_pending'] = 'HiPay Pselcionado (HiPay)';
$_['hipay_waiting'] = 'Aguarda confirmação de pagamento (HiPay)';
$_['hipay_cancelled'] = 'Pagamento cancelado (HiPay)';
$_['hipay_error'] = 'Pagamento falhou (HiPay)';
$_['hipay_error_ack'] = ' - Erro a processar o pagamento (HiPay)';
$_['hipay_success'] = 'Transação capturada - Pago (HiPay)';
$_['text_payment'] = 'A sua ordem apenas será finalizadas depois da receção da notificação do pagamento.';
