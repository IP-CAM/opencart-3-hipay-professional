<?php

// Text
$_['text_title'] = 'HiPay - Pay with Credit Card or local payment methods';
$_['hipay_pending'] = 'HiPay Payment Method selected (HiPay)';
$_['hipay_waiting'] = 'Waiting Payment Confirmation (HiPay)';
$_['hipay_cancelled'] = 'Payment cancelled (HiPay)';
$_['hipay_error'] = 'Payment Failed (HiPay)';
$_['hipay_error_ack'] = ' - Error processing payment (HiPay)';
$_['hipay_success'] = 'Payment Captured (HiPay)';
$_['text_payment'] = 'Your order will not ship until we receive payment confirmation.';
